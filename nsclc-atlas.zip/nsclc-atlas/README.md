# NSCLC Atlas

An interactive **single-cell RNA-seq cancer cell atlas** for the non-small cell
lung cancer (NSCLC) tumor microenvironment. Built as a teaching tool for
university students learning the standard scRNA-seq analysis workflow.

![stack](https://img.shields.io/badge/Next.js-14-black) ![ts](https://img.shields.io/badge/TypeScript-5-blue) ![tailwind](https://img.shields.io/badge/TailwindCSS-3-38bdf8)

## What it does

| View | What students learn |
|------|--------------------|
| **UMAP cell map** | How cells cluster by transcriptional identity; the immune / stromal / malignant compartments of a tumor. Zoom, pan, hover any cell. |
| **Gene feature plot** | Search a gene (e.g. `EPCAM`, `CD8A`, `FOXP3`) and color the UMAP by its expression — see marker specificity live. |
| **Composition charts** | Compare cell-type proportions across tumor vs. adjacent-normal tissue, and across patients. |
| **Marker dot plot** | The canonical scanpy-style dot plot: dot size = % of cells expressing, color = mean expression. Click a gene to jump to its feature plot. |

The app ships with a **biologically realistic synthetic dataset** (9,000 cells,
13 cell types, 50 canonical marker genes) so it runs instantly with no data
download. Swap in **real public data** whenever you're ready — see below.

## Learning layer (for university / grad students)

Built for a bioinformatics-level audience, the app includes a teaching layer on
top of the atlas:

- **Guided tour** — a step-by-step walkthrough (auto-opens on first visit,
  reopen from the **? Guided tour** button) that *drives the live app* — it sets
  the feature plot to EPCAM, then CD8A, so you see the concept as you read it.
- **Concepts tab** — expandable cards covering the real analysis pipeline: QC →
  `normalize_total`/`log1p` → HVGs → PCA → kNN graph → Leiden → UMAP → marker
  DE; plus UMAP interpretation traps, dropout/zero-inflation, the NSCLC tumor
  microenvironment, and compositional-analysis caveats (scCODA / Milo).
- **Exercises tab** — interactive challenges whose checkmarks update **live** as
  you drive the atlas (e.g. "color by a marker of CD8+ T cells" turns green when
  you do). Each has a hint, a "Show me" button, and a grad-level explanation.
- **"How to read this" notes** under every panel, flagging the common
  misconceptions (UMAP distances aren't quantitative, proportions are
  compositional and protocol-biased, etc.).

All content lives in `lib/learn.ts` — edit it to fit your course.

## Quick start

```bash
npm install
npm run dev
# open http://localhost:3000
```

Build for production / deploy to Vercel:

```bash
npm run build && npm start
```

This is a standard Next.js App Router project — push to a GitHub repo and import
it into [Vercel](https://vercel.com) for a zero-config deploy.

## Project structure

```
app/
  page.tsx            # main dashboard (client): state + layout
  layout.tsx          # root layout + metadata
  globals.css         # Tailwind + base styles
components/
  UmapPlot.tsx        # canvas UMAP: zoom / pan / hover / color modes
  GeneSearch.tsx      # gene autocomplete → feature plot
  Legend.tsx          # cell-type legend, click to isolate
  CompositionChart.tsx# stacked composition bars (tissue / patient)
  DotPlot.tsx         # marker gene dot plot
lib/
  types.ts            # shared TypeScript types
  data.ts             # loads meta.json + expr.bin, caches
  colors.ts           # viridis colormap + categorical palettes
public/data/
  meta.json           # cell metadata, coords, dotplot, composition
  expr.bin            # uint8 expression matrix (cell-major)
scripts/
  generate_demo_data.py  # makes the synthetic dataset
  convert_h5ad.py        # converts a real .h5ad into the same format
```

## Data format

`meta.json` holds per-cell arrays (`x`, `y`, `cellType`, `condition`, `sample`,
`patient`), the gene panel, cell-type colors, and precomputed `dotPlot` +
`composition`. `expr.bin` is a flat `Uint8Array` of per-gene min-max normalized
expression in **cell-major** order — the value for cell *i*, gene *j* is at index
`i * nGenes + j`, divided by 255 to get a 0–1 value for the color overlay.

Keeping expression in a compact binary (≈0.4 MB for 9k×50) means the whole atlas
loads in one round-trip and stays fast on a phone.

## Using real public data

The synthetic data is honest teaching data, but you can plug in a real published
NSCLC dataset at any time.

1. **Get an `.h5ad` (AnnData) file.** Good sources:
   - [CELLxGENE Discover](https://cellxgene.cziscience.com) — filter for lung / NSCLC, download `.h5ad`
   - Kim et al. 2020 — GEO `GSE131907` (~200k NSCLC cells)
   - Lambrechts et al. 2018 — ArrayExpress `E-MTAB-6149` / `E-MTAB-6653`

2. **Convert it** (needs `pip install scanpy anndata numpy --break-system-packages`):

   ```bash
   python scripts/convert_h5ad.py your_dataset.h5ad \
       --celltype  cell_type \
       --condition tissue \
       --sample    sample_id \
       --patient   patient_id \
       --max-cells 40000
   ```

   Point the `--celltype / --condition / --sample / --patient` flags at the
   matching columns in `adata.obs`. If the file has raw counts, add `--raw` to
   normalize + log1p. If there's no precomputed UMAP the script will compute one.

3. **Restart** `npm run dev`. The app reads the same `meta.json` + `expr.bin`, so
   no frontend changes are needed.

## Notes for students

- The synthetic expression model uses canonical markers with dropout, so feature
  plots and dot plots behave like real data (sparse, cell-type specific) — but
  the numbers are simulated, not measured. Always validate biology against the
  real published atlases before drawing conclusions.
- UMAP distances are **not** quantitative: nearby ≈ similar, but axis units are
  meaningless. This is a common point of confusion worth teaching explicitly.

## License

MIT — use freely for teaching and coursework.
