import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NSCLC Atlas — Single-Cell Cancer Cell Atlas",
  description:
    "Interactive single-cell RNA-seq atlas of the non-small cell lung cancer tumor microenvironment. A teaching tool for exploring cell types, gene expression, and tissue composition.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
