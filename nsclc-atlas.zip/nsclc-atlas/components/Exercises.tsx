"use client";

import { useState } from "react";
import type { ColorMode } from "@/lib/types";
import type { LearnAction } from "@/lib/learn";

export interface LiveState {
  colorMode: ColorMode;
  gene: string | null;
  highlight: number | null;
}

interface Props {
  state: LiveState;
  cellTypeIdByName: Record<string, number>;
  onApply: (a: LearnAction) => void;
}

interface Exercise {
  id: string;
  prompt: string;
  hint: string;
  explanation: string;
  // live check against app state; undefined = reveal-only (self-graded)
  check?: (s: LiveState, ids: Record<string, number>) => boolean;
  answer?: LearnAction; // "show me" action
}

const EXERCISES: Exercise[] = [
  {
    id: "cd8",
    prompt:
      "Locate the cytotoxic T-cell compartment: color the UMAP by a canonical marker of CD8+ T cells.",
    hint: "Think of the co-receptor that defines the CD8 lineage, or a cytotoxic granule gene (CD8A, CD8B, GZMK).",
    explanation:
      "CD8A/CD8B encode the CD8 co-receptor; GZMK is a cytotoxic effector. Their expression is confined to the CD8+ T cluster — the exact region you'd gate for anti-tumor cytotoxic activity and exhaustion analysis.",
    check: (s) => s.colorMode === "gene" && ["CD8A", "CD8B", "GZMK"].includes(s.gene ?? ""),
    answer: { kind: "gene", gene: "CD8A" },
  },
  {
    id: "treg",
    prompt:
      "Tregs are immunosuppressive and clinically important in NSCLC. Color by the lineage-defining transcription factor of regulatory T cells.",
    hint: "It's a forkhead-box transcription factor — the master regulator of the Treg program.",
    explanation:
      "FOXP3 is the master transcription factor of Tregs. Note it marks a small subset within the CD4+ T region, not a fully separate island — a good example of why sub-clustering is often needed to resolve related states.",
    check: (s) => s.colorMode === "gene" && s.gene === "FOXP3",
    answer: { kind: "gene", gene: "FOXP3" },
  },
  {
    id: "prolif",
    prompt:
      "Which compartment is actively proliferating? Color by a cell-cycle / proliferation marker and see where it concentrates.",
    hint: "Classic proliferation markers include MKI67 (Ki-67) and TOP2A.",
    explanation:
      "MKI67 and TOP2A mark cycling cells. In this atlas the signal concentrates in the malignant epithelial cluster — uncontrolled proliferation is a defining hallmark of the tumor compartment, and inferred CNV would confirm these are the aneuploid cells.",
    check: (s) => s.colorMode === "gene" && ["MKI67", "TOP2A"].includes(s.gene ?? ""),
    answer: { kind: "gene", gene: "MKI67" },
  },
  {
    id: "immune",
    prompt:
      "Find the single gene that best separates the immune compartment from the epithelial + stromal cells.",
    hint: "It encodes the pan-leukocyte surface phosphatase, better known as CD45.",
    explanation:
      "PTPRC (CD45) is expressed across essentially all leukocytes and absent from epithelial, fibroblast, and endothelial cells. It's the first split most annotation strategies make: immune vs. non-immune.",
    check: (s) => s.colorMode === "gene" && s.gene === "PTPRC",
    answer: { kind: "gene", gene: "PTPRC" },
  },
  {
    id: "isolate",
    prompt:
      "Isolate the malignant epithelial cells using the legend, and observe where they sit relative to normal alveolar epithelial cells.",
    hint: "Click a cell type in the sidebar legend to dim everything else.",
    explanation:
      "Malignant and alveolar epithelial cells are both EPCAM+ and sit near each other, yet form distinct clusters — the transcriptional distance driven by malignant transformation (and CNV) is what separates them. Distinguishing the two is exactly the malignant-cell-calling problem (inferCNV / CopyKAT).",
    check: (s, ids) => s.highlight === ids["Malignant epithelial"],
    answer: { kind: "highlight", cellType: "Malignant epithelial" },
  },
  {
    id: "composition",
    prompt:
      "Conceptual: the composition bars show malignant cells expanding in tumor tissue. Name one technical artifact that could inflate or deflate an apparent cell-type proportion.",
    hint: "Think about what happens to cells physically during tissue dissociation.",
    explanation:
      "Dissociation bias (fragile cells like neutrophils/epithelium are lost, robust cells enriched), single-cell vs single-nucleus protocol differences, ambient RNA, and doublets all distort proportions. This is why compositional shifts should be treated as hypotheses and analyzed with methods like scCODA or Milo.",
  },
  {
    id: "umap-trap",
    prompt:
      "Conceptual: a student claims two clusters on opposite sides of the UMAP are 'twice as different' as two adjacent clusters. Why is this reasoning flawed?",
    hint: "Consider what UMAP preserves — and what it does not.",
    explanation:
      "UMAP preserves local neighborhoods, not global distances. The space between clusters and the axis units are not quantitative, so you cannot read magnitude of difference off the layout. Quantify differences with expression statistics or distances in PCA space instead.",
  },
];

export default function Exercises({ state, cellTypeIdByName, onApply }: Props) {
  const [openHint, setOpenHint] = useState<Record<string, boolean>>({});
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});

  const solvedCount = EXERCISES.filter(
    (e) => e.check && e.check(state, cellTypeIdByName),
  ).length;
  const checkable = EXERCISES.filter((e) => e.check).length;

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <p className="text-xs text-slate-500">
          Interactive challenges — the checkmarks update live as you drive the atlas above.
        </p>
        <span className="rounded-full bg-slate-800 px-2.5 py-1 text-[11px] font-mono text-slate-300">
          {solvedCount}/{checkable} solved
        </span>
      </div>

      <ol className="flex flex-col gap-2.5">
        {EXERCISES.map((e, i) => {
          const solved = e.check ? e.check(state, cellTypeIdByName) : false;
          const isReveal = !e.check;
          return (
            <li
              key={e.id}
              className={`rounded-lg border p-3 transition ${
                solved
                  ? "border-emerald-600/60 bg-emerald-950/20"
                  : "border-slate-800 bg-slate-900/50"
              }`}
            >
              <div className="flex items-start gap-2.5">
                <span
                  className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[11px] font-bold ${
                    solved
                      ? "bg-emerald-500 text-white"
                      : "bg-slate-700 text-slate-300"
                  }`}
                >
                  {solved ? "✓" : i + 1}
                </span>
                <div className="flex-1">
                  <p className="text-sm text-slate-200">{e.prompt}</p>

                  <div className="mt-2 flex flex-wrap gap-3 text-[11px]">
                    <button
                      onClick={() =>
                        setOpenHint((h) => ({ ...h, [e.id]: !h[e.id] }))
                      }
                      className="text-slate-400 hover:text-slate-200"
                    >
                      {openHint[e.id] ? "Hide hint" : "Hint"}
                    </button>
                    {e.answer && (
                      <button
                        onClick={() => onApply(e.answer!)}
                        className="text-sky-400 hover:text-sky-300"
                      >
                        Show me
                      </button>
                    )}
                    {isReveal && (
                      <button
                        onClick={() =>
                          setRevealed((r) => ({ ...r, [e.id]: !r[e.id] }))
                        }
                        className="text-sky-400 hover:text-sky-300"
                      >
                        {revealed[e.id] ? "Hide answer" : "Reveal answer"}
                      </button>
                    )}
                  </div>

                  {openHint[e.id] && (
                    <p className="mt-2 text-[11px] italic text-slate-500">{e.hint}</p>
                  )}

                  {(solved || (isReveal && revealed[e.id])) && (
                    <p className="mt-2 rounded bg-slate-800/60 p-2 text-[11px] leading-relaxed text-slate-300">
                      {e.explanation}
                    </p>
                  )}
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
