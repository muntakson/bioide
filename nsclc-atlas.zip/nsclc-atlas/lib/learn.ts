// Educational content for the NSCLC Atlas, written for bioinformatics /
// graduate-level students. Kept as data so components stay presentational.

import type { ColorMode } from "./types";

/** An action the walkthrough can apply to the live app to demonstrate a point. */
export type LearnAction =
  | { kind: "mode"; mode: ColorMode }
  | { kind: "gene"; gene: string }
  | { kind: "highlight"; cellType: string }
  | { kind: "clear" };

export interface TourStep {
  title: string;
  body: string;
  action?: LearnAction;
}

export const TOUR: TourStep[] = [
  {
    title: "Welcome to the NSCLC Atlas",
    body:
      "This is an interactive single-cell RNA-seq atlas of the non-small cell lung cancer tumor microenvironment. In the next few steps we'll walk through the standard analysis outputs you'd produce in Scanpy or Seurat. You can reopen this tour any time from the “?” button.",
  },
  {
    title: "The UMAP embedding",
    body:
      "Every point is one cell, positioned by a UMAP embedding of its top principal components. Transcriptionally similar cells sit together, forming the clusters you see. We've colored them by annotated cell type — the immune, stromal, and malignant compartments of the tumor.",
    action: { kind: "mode", mode: "cellType" },
  },
  {
    title: "Feature plots (gene expression)",
    body:
      "Overlaying a single gene's expression onto the embedding is a “feature plot”. Here is EPCAM, an epithelial marker — it lights up the malignant and alveolar epithelial clusters and is silent in immune cells. Use the gene search in the sidebar to try any marker.",
    action: { kind: "gene", gene: "EPCAM" },
  },
  {
    title: "Cell-type annotation via markers",
    body:
      "CD8A marks cytotoxic CD8+ T cells. Compare its feature plot to EPCAM: the signal has moved to a completely different region. This is how clusters get their labels — by the canonical markers they express (rank_genes_groups → manual or automated annotation).",
    action: { kind: "gene", gene: "CD8A" },
  },
  {
    title: "Composition & the dot plot",
    body:
      "Below the map, the composition bars compare cell-type proportions across tumor vs. adjacent-normal tissue, and the dot plot summarizes every marker at once (size = % of cells expressing, color = scaled mean expression). Together these are the core figures of any atlas paper.",
    action: { kind: "clear" },
  },
  {
    title: "Now try it yourself",
    body:
      "Head to the Concepts tab for the methods behind each view, and the Exercises tab for guided challenges that check your reasoning against the live atlas. Happy exploring!",
  },
];

export interface Concept {
  id: string;
  title: string;
  summary: string;
  body: string[]; // paragraphs
}

export const CONCEPTS: Concept[] = [
  {
    id: "workflow",
    title: "The scRNA-seq analysis workflow",
    summary: "From raw counts to an annotated atlas — the canonical pipeline.",
    body: [
      "A standard droplet-based (e.g. 10x) analysis starts from a cell × gene count matrix. Quality control removes empty droplets and low-quality cells using thresholds on total counts, number of detected genes, and mitochondrial read fraction (a proxy for lysed/dying cells).",
      "Counts are then library-size normalized (normalize_total, typically to 1e4) and log1p-transformed to stabilize variance. Highly variable genes (HVGs, ~2,000) are selected, the data is scaled, and PCA reduces it to ~30–50 components that capture the dominant axes of variation.",
      "A k-nearest-neighbor graph is built in PCA space, clustered with Leiden (or Louvain), and embedded in 2D with UMAP for visualization. Clusters are annotated by differential expression (rank_genes_groups, Wilcoxon) against canonical markers, or with automated tools such as CellTypist.",
      "In cancer studies, an extra step distinguishes malignant from non-malignant cells — often via inferred copy-number variation (inferCNV / CopyKAT) rather than expression alone, since tumor cells are aneuploid.",
    ],
  },
  {
    id: "umap",
    title: "Reading a UMAP (and its traps)",
    summary: "Local structure is meaningful; global geometry mostly is not.",
    body: [
      "UMAP is a non-linear manifold embedding. It is tuned to preserve local neighborhoods, so cells near each other are genuinely similar. It does not faithfully preserve global distances: the gap between two far-apart clusters is not proportional to their transcriptional difference.",
      "Consequences worth teaching: axis units are meaningless, cluster area does not indicate abundance or importance, and apparent “bridges” between clusters can be embedding artifacts rather than true intermediate states.",
      "The layout depends on hyperparameters (n_neighbors trades local vs. global structure; min_dist controls packing) and on the upstream PCA and batch correction. Always interpret UMAP alongside quantitative evidence — marker expression, cluster statistics, and abundance tests — never on its own.",
    ],
  },
  {
    id: "markers",
    title: "Marker genes & the dot plot",
    summary: "How annotation is justified and visualized.",
    body: [
      "A marker is a gene enriched in one population relative to the rest. Differential expression per cluster (Wilcoxon rank-sum is the Scanpy default) yields ranked candidate markers; effect size and fraction-expressing matter more than p-value alone at single-cell scale, where n is huge and everything is “significant”.",
      "The dot plot encodes two quantities simultaneously: dot size = fraction of cells in the group expressing the gene (detection), and color = mean expression among the group, usually min-max or z-scaled per gene so lineage patterns are comparable across genes.",
      "Reading it: a large, bright dot means most cells of that type express the gene strongly — a good marker. Small or dark dots indicate rare or low expression. The block-diagonal structure you see is the signature of well-separated, correctly annotated cell types.",
    ],
  },
  {
    id: "dropout",
    title: "Dropout, sparsity & zeros",
    summary: "Why scRNA-seq matrices are ~90% zero.",
    body: [
      "Single-cell matrices are extremely sparse. Zeros are a mix of biological zeros (the gene is truly off) and technical zeros / “dropout” (the transcript was present but not captured, due to low mRNA capture efficiency per cell).",
      "This is why per-cell feature plots look grainy even for good markers: many positive cells read zero simply by sampling. It also motivates the log1p transform, careful normalization, and — controversially — imputation methods (MAGIC, scVI) that borrow information across similar cells.",
      "Modeling choices follow from this: count models (negative binomial / zero-inflated NB, as in scVI) respect the discrete, over-dispersed, zero-heavy nature of the data better than treating log-normalized values as Gaussian.",
    ],
  },
  {
    id: "tme",
    title: "The NSCLC tumor microenvironment",
    summary: "Who's who, and why it's clinically important.",
    body: [
      "The tumor is an ecosystem. Beyond malignant epithelial cells you find a lymphoid compartment (CD8+ cytotoxic T cells, CD4+ helper T cells, immunosuppressive FOXP3+ Tregs, NK cells, B and plasma cells), a myeloid compartment (tumor-associated macrophages, monocytes, dendritic cells, mast cells), and stroma (cancer-associated fibroblasts, endothelial cells).",
      "Comparing tumor to matched adjacent-normal tissue reveals remodeling: expansion of malignant and myeloid populations, and shifts in T-cell state toward exhaustion (PDCD1, HAVCR2, LAG3, TOX). These states underpin response and resistance to immune-checkpoint blockade (anti-PD-1/PD-L1), the backbone of modern NSCLC immunotherapy.",
      "This is why single-cell atlases matter clinically: they map the cellular targets and biomarkers that bulk sequencing averages away.",
    ],
  },
  {
    id: "composition",
    title: "Compositional analysis & its caveats",
    summary: "Proportions are informative — and easy to misread.",
    body: [
      "Cell-type proportions are compositional: they sum to 1, so an increase in one population mechanically decreases the others. Naive per-cell-type proportion tests inflate false positives; use compositional-aware methods (scCODA) or neighborhood-based differential abundance (Milo).",
      "Proportions are also biased by the protocol. Tissue dissociation preferentially loses fragile cell types (neutrophils, some epithelial cells) and enriches robust ones; single-nucleus vs. single-cell protocols recover different fractions. Ambient RNA and doublets further distort counts.",
      "Practical rule for students: treat composition shifts as hypotheses to validate (e.g. with imaging/flow), and always report the protocol. The tumor-vs-normal expansion of malignant cells shown here is real biology, but its exact magnitude is protocol-dependent.",
    ],
  },
];
