import type { Atlas, AtlasMeta } from "./types";

let cached: Promise<Atlas> | null = null;

/** Load meta.json + expr.bin once and cache the result. */
export function loadAtlas(): Promise<Atlas> {
  if (cached) return cached;
  cached = (async () => {
    const [metaRes, exprRes] = await Promise.all([
      fetch("/data/meta.json"),
      fetch("/data/expr.bin"),
    ]);
    if (!metaRes.ok) throw new Error("Failed to load meta.json");
    if (!exprRes.ok) throw new Error("Failed to load expr.bin");
    const meta = (await metaRes.json()) as AtlasMeta;
    const buf = await exprRes.arrayBuffer();
    const expr = new Uint8Array(buf);
    const nGenes = meta.dataset.nGenes;
    return {
      meta,
      expr,
      exprAt: (cell: number, gene: number) => expr[cell * nGenes + gene] / 255,
    } satisfies Atlas;
  })();
  return cached;
}
